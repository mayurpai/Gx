# Rasa_CustomUI-v_2.0

A Chat widget easy to connect to RASA bot to Custom Channel(a webpage).

Added Support for 
- Buttons
- Images

Command to start the bot:

> rasa run -m models --enable-api --cors "*" --debug

## Screenshots:

![ScreenShot](https://github.com/JiteshGaikwad/Rasa_CustomUI-v_2.0/blob/master/static/img/ui_1.PNG)

![ScreenShot](https://github.com/JiteshGaikwad/Rasa_CustomUI-v_2.0/blob/master/static/img/ui_2.PNG)


